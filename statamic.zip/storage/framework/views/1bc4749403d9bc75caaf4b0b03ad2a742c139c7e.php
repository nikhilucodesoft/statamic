<?php $__env->startSection('title', $data['main_heading']); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold my-6"><?php echo e($data['title']); ?></h1>
    <?php echo $data['content']; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('store.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/projects/statamic-exmple/resources/views/store/front-page.blade.php ENDPATH**/ ?>