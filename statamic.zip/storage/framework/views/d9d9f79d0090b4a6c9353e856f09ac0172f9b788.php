<?php use function Statamic\trans as __; ?>


<?php $__env->startSection('title', __('Assets')); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('statamic::partials.empty-state', [
        'title' => __('Asset Containers'),
        'description' => __('statamic::messages.asset_container_intro'),
        'svg' => 'empty/asset-container',
        'button_text' => __('Create Asset Container'),
        'button_url' => cp_route('asset-containers.create'),
        'can' => $user->can('create', \Statamic\Contracts\Assets\AssetContainer::class)
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('statamic::partials.docs-callout', [
        'topic' => __('Assets'),
        'url' => 'assets'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('statamic::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/projects/statamic-exmple/vendor/statamic/cms/src/Providers/../../resources/views/assets/index.blade.php ENDPATH**/ ?>