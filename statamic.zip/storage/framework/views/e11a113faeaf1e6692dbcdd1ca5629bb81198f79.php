<?php use function Statamic\trans as __; ?>


<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>

    <?php if($showBreadcrumb): ?>
        <?php echo $__env->make('statamic::partials.breadcrumb', [
            'url' => cp_route('preferences.index'),
            'title' => __('Preferences'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <preferences-edit-form
        title="<?php echo e($title); ?>"
        :blueprint='<?php echo json_encode($blueprint, 15, 512) ?>'
        :meta='<?php echo json_encode($meta, 15, 512) ?>'
        :values='<?php echo json_encode($values, 15, 512) ?>'
        action="<?php echo e($actionUrl); ?>"
        :save-as-options="<?php echo e(json_encode($saveAsOptions)); ?>"
    ></preferences-edit-form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('statamic::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/projects/statamic-exmple/vendor/statamic/cms/src/Providers/../../resources/views/preferences/edit.blade.php ENDPATH**/ ?>