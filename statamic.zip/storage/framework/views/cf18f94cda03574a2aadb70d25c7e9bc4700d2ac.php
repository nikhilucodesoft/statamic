<?php use function Statamic\trans as __; ?>


<?php $__env->startSection('title', __('Create Asset Container')); ?>

<?php $__env->startSection('content'); ?>

    <asset-container-create-form
        initial-title="<?php echo e(__('Create Asset Container')); ?>"
        :blueprint="<?php echo e(json_encode($blueprint)); ?>"
        :initial-values="<?php echo e(json_encode($values)); ?>"
        :meta="<?php echo e(json_encode($meta)); ?>"
        url="<?php echo e(cp_route('asset-containers.store')); ?>"
        listing-url="<?php echo e(cp_route('assets.browse.index')); ?>"
        action="post"
    ></asset-container-create-form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('statamic::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/projects/statamic-exmple/vendor/statamic/cms/src/Providers/../../resources/views/assets/containers/create.blade.php ENDPATH**/ ?>